export class Article {
    title: string;
    text: string;
}