import { Member } from './member';

//TODO: Turn this stuff into JSON 
export const MEMBERS: Member[] = [
    { firstName: 'Lucas', lastName: 'Togt', insertion: 'van der', dob: new Date(1998, 1, 26), bio: "great moves", id: 0 },
    { firstName: 'Tom', lastName: 'Gelooven', insertion: 'van', dob: new Date(1998, 1, 26), bio: "great moves", id: 1 },
    { firstName: 'Michiel', lastName: 'Versnel', insertion: '', dob: new Date(1998, 1, 26), bio: "great moves", id: 2 },
    { firstName: 'Stijn', lastName: 'Makkus', insertion: '', dob: new Date(1998, 1, 26), bio: "great moves", id: 3 },
    { firstName: 'Anton', lastName: 'Es', insertion: 'van', dob: new Date(1998, 1, 26), bio: "great moves", id: 4 },
    { firstName: 'Edward', lastName: 'Hissink', insertion: '', dob: new Date(1998, 1, 26), bio: "great moves", id: 5 },
    { firstName: 'David', lastName: 'Vorm', insertion: 'van der', dob: new Date(1998, 1, 26), bio: "great moves", id: 6 },
    { firstName: 'David', lastName: 'Lim', insertion: '', dob: new Date(1998, 1, 26), bio: "great moves", id: 7 },
    { firstName: 'Leander', lastName: 'Kalff', insertion: '', dob: new Date(1998, 1, 26), bio: "great moves", id: 8 },
    { firstName: 'Joris', lastName: 'Kerkhofs', insertion: '', dob: new Date(1998, 1, 26), bio: "great moves", id: 9 },
    { firstName: 'Daniel', lastName: 'Otten', insertion: 'van', dob: new Date(1998, 1, 26), bio: "great moves", id: 10 },
] 