export class Member {
    id: number;
    firstName: string;
    lastName: string;
    insertion: string;
    dob: Date;
    bio: string;
}