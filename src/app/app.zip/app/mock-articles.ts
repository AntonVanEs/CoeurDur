export const ARTICLES = [
    { title: 'Article One', text: "The world ended today. It ended when you said goodbye."},
    { title: 'Article Two', text: "They are taking the hobbits to Isengard. To Isengard. Gard gard g-gard." },
    { title: 'Article Three', text: "Dread it. Run from it. Destiny arrives none the less."},
    { title: 'Article Four', text: "I used to be an adventurer like you. Then I took an arrow to the knee."},
    { title: 'Article Five', text: "I am Iron Man." }
];